Readme file
Prerequisite:
�	Xampp
�       Atom Editor
�	Chrome web bowser

Steps to start executing the code
�	Download and install xampp software refer the following link to complete the setup https://www.youtube.com/watch?v=zZ6NQRUYR2E
�	Download and install atom editor 
�	After the required softwares are downloaded and installed open xampp and click start on apache and mysql in the xampp main page.
�	If there is an error in starting mysql  or apache then delete previously installed mysql software, refer the following link for any doubts
�	If the error still exist then try changing the port numbers, refer the following link for any doubts  https://www.youtube.com/watch?v=8PvLprNHWKs&t=80s
�	After the mysql and apache are started then open the browser and type http://localhost/phpmyadmin/ this will lead you to the backend of the program and we can add and delete databases as per your choice.
�	To run the arms and ammunition project select the import tab present at the header of the php Myadmin page.
�	Choose the desired file mini.sql and press go.
�	The required database and tables will be created on the php myadmin page. Now we can review our backend database and insert and delete records.
�	After the database creation is complete then open the browser and type http://localhost/ suffixed with the required php file to be opened eg;- http://localhost/index.html.
�	After the web page opens you can choose any options according to your desire and review the whole website.
�	After this proceed as you like to different pages and to edit the code open the php file with atom editor.
�	In the atom editor you can add or alter any functionality of your choice.

